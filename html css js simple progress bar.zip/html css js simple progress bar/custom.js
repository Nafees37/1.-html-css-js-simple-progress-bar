function myfun() {
  document.getElementById("div1").style.background = "#00a8ff";

  document.getElementById("div2").style.background = "#009432";

  document.getElementById("div3").style.background = "#006266";
}

function myfun1() {
  document.getElementById("div1").style.background = "#006266";

  document.getElementById("div2").style.background = "#1B1464";

  document.getElementById("div3").style.background = "#00a8ff";
}
